//
//  SettingsViewController.swift
//  Meditatio kz
//
//  Created by Abai Kalikov on 10/15/19.
//  Copyright © 2019 Nazhmeddin Babakhanov. All rights reserved.
//

import UIKit

class SettingsViewController: UIViewController {
    
    lazy var backButton: UIButton = {
        let button = UIButton()
        button.setImage(#imageLiteral(resourceName: "backIcon"), for: .normal)
        button.addTarget(self, action: #selector(backButtonPressed), for: .touchUpInside)
        button.contentHorizontalAlignment = UIControl.ContentHorizontalAlignment.left
        return button
    }()
    
    lazy var parametersLabel: CustomSignInLabel = {
        let label = CustomSignInLabel(title: "Параметрлер", size: 32.0, fontType: "bold", color: .mainPurple)
        return label
    }()
    
    @objc
    func backButtonPressed() {
        
    }
    
    lazy var tableView: UITableView = {
        let tableView = UITableView()
        tableView.register(ParameterCell.self, forCellReuseIdentifier: ParameterCell.name)
        tableView.dataSource = self
        tableView.delegate = self
        tableView.isScrollEnabled = false
        tableView.separatorStyle = .none
        return tableView
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Параметрлер"
        setupViews()
        setupLayout()
    }
    
    func setupViews() {
        view.backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        view.addSubViews(views: [backButton, parametersLabel, tableView])
    }
    
    func setupLayout() {
        backButton.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(ConstraintConstants.h35)
            make.left.equalToSuperview().offset(ConstraintConstants.w15)
            make.width.equalTo(ConstraintConstants.w30)
            make.height.equalTo(ConstraintConstants.w30)
        }
        
        parametersLabel.snp.makeConstraints { (make) in
            make.top.equalTo(backButton.snp.bottom).offset(ConstraintConstants.h20)
            make.left.equalToSuperview().offset(ConstraintConstants.w15)
            make.height.equalTo(ConstraintConstants.h30)
            make.width.equalToSuperview()
        }
        
        tableView.snp.makeConstraints { make in
            make.width.centerX.equalToSuperview()
            make.height.equalToSuperview().multipliedBy(0.4)
            make.top.equalTo(parametersLabel.snp.bottom).offset(view.bounds.height * 0.05)
        }
    }
}

extension SettingsViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: ParameterCell.name, for: indexPath) as! ParameterCell
        let menuOption = ParametersOption.init(rawValue: indexPath.row)
        cell.mainLabel.text = menuOption?.description
        cell.cursorView.image = menuOption?.cursorPhoto
        if indexPath.row == 1 {
            cell.cursorView.isHidden = true
            cell.switchOnOff.isHidden = false
        }
        cell.mainLabel.text = menuOption?.description
        cell.cursorView.image = menuOption?.cursorPhoto
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let row = indexPath.row
        let menuOption = ParametersOption.init(rawValue: row)
        
        if row == 0 {
            present(menuOption!.viewControllers, animated: true, completion: nil)
        }else if row == 3{
            StorageManager.shared.removeSavedData()
            appDelegate.navigateToLoginViewController()
        }

    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return view.bounds.height * 0.08
    }
}
