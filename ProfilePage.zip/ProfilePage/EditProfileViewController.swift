//
//  EditProfileViewController.swift
//  Meditatio kz
//
//  Created by Abai Kalikov on 10/15/19.
//  Copyright © 2019 Nazhmeddin Babakhanov. All rights reserved.
//

import Foundation
import UIKit

class EditProfileViewController: UIViewController {
    
    lazy var backButton: UIButton = {
        let button = UIButton()
        button.setImage(#imageLiteral(resourceName: "backIcon"), for: .normal)
        button.addTarget(self, action: #selector(backButtonPressed), for: .touchUpInside)
        button.contentHorizontalAlignment = UIControl.ContentHorizontalAlignment.left
        return button
    }()
    
    lazy var changeProfileLabel: CustomSignInLabel = {
        let label = CustomSignInLabel(title: "Профильді өзгерту", size: 20.0, fontType: "default", color: .mainPurple)
        return label
    }()
    
    lazy var profileImageView: UIImageView = {
        let image = UIImageView()
        image.image = #imageLiteral(resourceName: "pexels-photo-999311")
        image.clipsToBounds = true
        image.layer.masksToBounds = true
        image.contentMode = UIView.ContentMode.scaleToFill
        image.layer.cornerRadius = 10
        return image
    }()
    
    lazy var nameLabel: CustomSignInLabel = {
        let label = CustomSignInLabel(title: "Аты", size: 16.0, fontType: "default", color: .mainPurple)
        return label
    }()
    
    lazy var nameTextField: CustomSignInTextField = {
        let tf = CustomSignInTextField(padding: 40, height: 55, option: .nameTextField)
        return tf
    }()
    
    lazy var emailLabel: CustomSignInLabel = {
        let label = CustomSignInLabel(title: "Пошта", size: 16.0, fontType: "default", color: .mainPurple)
        return label
    }()
    
    lazy var emailTextField: CustomSignInTextField = {
        let tf = CustomSignInTextField(padding: 40, height: 55, option: .emailTextField)
        return tf
    }()
    
    lazy var passwordLabel: CustomSignInLabel = {
        let label = CustomSignInLabel(title: "Пароль", size: 16.0, fontType: "default", color: .mainPurple)
        return label
    }()
    
    lazy var passwordTextField: CustomSignInTextField = {
        let tf = CustomSignInTextField(padding: 40, height: 55, option: .passwordTextField)
        tf.isSecureTextEntry = true
        return tf
    }()
    
    lazy var stackView: UIStackView = {
        let stackView = UIStackView(arrangedSubviews: [nameLabel, nameTextField, emailLabel, emailTextField, passwordLabel, passwordTextField])
        stackView.axis = .vertical
        stackView.spacing = 1
        stackView.distribution = .fillEqually
        stackView.layer.borderColor = #colorLiteral(red: 0.5568627715, green: 0.3529411852, blue: 0.9686274529, alpha: 1)
        stackView.layer.borderWidth = 1.0
        return stackView
    }()
    
    lazy var updateProfileButton: UIButton = {
        let button = UIButton()
        button.setTitle("Профильді жаңарту", for: .normal)
        button.backgroundColor = #colorLiteral(red: 0.5568627715, green: 0.3529411852, blue: 0.9686274529, alpha: 1)
        button.titleLabel?.tintColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        button.addTarget(self, action: #selector(updateProfilePressed), for: .touchUpInside)
        button.contentHorizontalAlignment = UIControl.ContentHorizontalAlignment.center
        button.clipsToBounds = true
        button.layer.cornerRadius = 10
        return button
    }()
    
    @objc
    func backButtonPressed() {
        dismiss(animated: true, completion: nil)
    }
    
    @objc
    func updateProfilePressed() {
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        navigationItem.title = "Профильді өзгерту"
        setupViews()
        setupLayout()
    }
    
    func setupViews() {
        view.addSubViews(views: [backButton, changeProfileLabel, profileImageView, stackView, updateProfileButton])
    }
    
    func setupLayout() {
        backButton.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(ConstraintConstants.h40)
            make.left.equalToSuperview().offset(ConstraintConstants.w13)
            make.width.equalTo(ConstraintConstants.w30)
            make.height.equalTo(ConstraintConstants.w30)
        }
        
        changeProfileLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(ConstraintConstants.h40)
            make.left.equalTo(backButton.snp.right).offset(ConstraintConstants.w50)
            make.width.equalToSuperview()
            make.height.equalTo(ConstraintConstants.w30)
        }
        
        profileImageView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(ConstraintConstants.h90)
            make.centerX.equalToSuperview()
            make.width.height.equalTo(ConstraintConstants.w120)
        }
        
        stackView.snp.makeConstraints { (make) in
            make.top.equalTo(profileImageView.snp.bottom).offset(ConstraintConstants.h30)
            make.left.equalTo(backButton.snp.left)
            make.right.equalToSuperview().offset(-ConstraintConstants.w13)
            make.height.equalToSuperview().multipliedBy(0.4)
        }
        
        updateProfileButton.snp.makeConstraints { (make) in
            make.height.equalTo(ConstraintConstants.h40)
            make.left.equalTo(stackView)
            make.right.equalTo(stackView)
            make.bottom.equalToSuperview().offset(-ConstraintConstants.h25)
        }
    }
}
