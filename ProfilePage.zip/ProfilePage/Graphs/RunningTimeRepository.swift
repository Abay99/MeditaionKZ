//
//  RunningTimeRepository.swift
//  Meditatio kz
//
//  Created by Abai Kalikov on 10/22/19.
//  Copyright © 2019 Nazhmeddin Babakhanov. All rights reserved.
//

import Foundation

class RunningTimeRepository {
    
    static let instance = RunningTimeRepository()
    
    var timeGraphCollection: [TimeGraphData]?
    
    func retrieveTimeGraphCollection (completion: @escaping ([TimeGraphData]?) -> ()) {
        
        if timeGraphCollection != nil {
            completion(timeGraphCollection)
        } else {
            timeGraphCollection = self.createTimeCollection()
            completion(timeGraphCollection)
        }
    }
    
    private func createTimeCollection () -> [TimeGraphData] {
        
        let monday = TimeGraphData.init(order: 0, amount: "0", month: "ДС", percentage: 0)
        let tuesday = TimeGraphData.init(order: 1, amount: "16", month: "СС", percentage: 16)
        let wednesday = TimeGraphData.init(order: 2, amount: "32'", month: "СР", percentage: 32)
        let thursday = TimeGraphData.init(order: 3, amount: "48", month: "БС", percentage: 48)
        let friday = TimeGraphData.init(order: 3, amount: "64", month: "ЖМ", percentage: 64)
        let saturday = TimeGraphData.init(order: 3, amount: "80", month: "СБ", percentage: 80)
        let sunday = TimeGraphData.init(order: 3, amount: "100", month: "ЖС", percentage: 100)
        
        return [monday, tuesday, wednesday, thursday, friday, saturday, sunday]
    }
}
