//
//  ProfileCalendarView.swift
//  Meditatio kz
//
//  Created by Abai Kalikov on 10/23/19.
//  Copyright © 2019 Nazhmeddin Babakhanov. All rights reserved.
//

import Foundation
import UIKit
import FSCalendar

class CalendarViewController: UIViewController {
    
    let sessions: [SessionData] = [
        SessionData(sessionTitle: "Тынысыңызды байқаныз", programTitle: "Стрессті жеңілдету"),
        SessionData(sessionTitle: "Тынысыңызды байқаныз", programTitle: "Стрессті жеңілдету"),
        SessionData(sessionTitle: "Тынысыңызды байқаныз", programTitle: "Стрессті жеңілдету"),
        SessionData(sessionTitle: "Тынысыңызды байқаныз", programTitle: "Стрессті жеңілдету"),
        SessionData(sessionTitle: "Тынысыңызды байқаныз", programTitle: "Стрессті жеңілдету"),
        SessionData(sessionTitle: "Тынысыңызды байқаныз", programTitle: "Стрессті жеңілдету")
    ]
    
    fileprivate lazy var dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "kk")
        formatter.dateFormat = "MMMM, d"
        return formatter
    }()
    
    lazy var calendar: FSCalendar = {
        let calendar = FSCalendar()
        calendar.dataSource = self
        calendar.delegate = self
        calendar.firstWeekday = 2
        calendar.appearance.headerTitleColor = .mainPurple
        calendar.appearance.headerTitleFont = UIFont.boldSystemFont(ofSize: 20.0)
        calendar.appearance.titleDefaultColor = .mainPurple
        calendar.appearance.titleSelectionColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        calendar.appearance.todayColor = .mainPurple
        calendar.appearance.weekdayTextColor = .mainPurple
        calendar.appearance.selectionColor = #colorLiteral(red: 0.5568627715, green: 0.3529411852, blue: 0.9686274529, alpha: 1)
        calendar.appearance.titleSelectionColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        var locale = NSLocale(localeIdentifier: "kk")
        calendar.locale = locale as Locale
        calendar.appearance.caseOptions = [.headerUsesUpperCase,.weekdayUsesUpperCase]
        return calendar
    }()
    
    lazy var selectedDateLabel: CustomSignInLabel = {
        let label = CustomSignInLabel(title: "Cәрсенбі, 23", size: 16.0, fontType: "default", color: .mainPurple)
        label.textAlignment = .left
        return label
    }()
    
    lazy var sessionNumberLabel: CustomSignInLabel = {
        let label = CustomSignInLabel(title: "2 сеанс", size: 16.0, fontType: "default", color: .mainPurple)
        label.textAlignment = .right
        return label
    }()
    
    lazy var tableView: UITableView = {
        let tableView = UITableView()
        tableView.register(SessionCell.self, forCellReuseIdentifier: SessionCell.name)
        tableView.dataSource = self
        tableView.delegate = self
        tableView.isScrollEnabled = true
        tableView.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        tableView.separatorStyle = .none
        return tableView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupInitialViews()
        setupViews()
        setupLayout()
    }
    
    func setupInitialViews() {
        view.backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        view.clipsToBounds = true
        view.layer.cornerRadius = 10
        view.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.2).cgColor
        view.layer.shadowOffset = CGSize(width: 3, height: 3)
        view.layer.shadowOpacity = 1.0
        view.layer.shadowRadius = 4.0
        view.layer.masksToBounds = false
    }
    
    func setupViews() {
        view.addSubViews(views: [calendar, selectedDateLabel, sessionNumberLabel, tableView])
    }
    
    func setupLayout() {
        calendar.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(ConstraintConstants.h220)
        }
        
        selectedDateLabel.snp.makeConstraints { (make) in
            make.top.equalTo(calendar.snp.bottom)
            make.left.equalToSuperview().offset(ConstraintConstants.w13)
            make.width.equalToSuperview()
            make.height.equalTo(ConstraintConstants.h20)
        }
        
        sessionNumberLabel.snp.makeConstraints { (make) in
            make.top.equalTo(calendar.snp.bottom)
            make.right.equalToSuperview().offset(-ConstraintConstants.w13)
            make.width.equalToSuperview()
            make.height.equalTo(ConstraintConstants.h20)
        }
        
        tableView.snp.makeConstraints { (make) in
            make.top.equalTo(selectedDateLabel.snp.bottom).offset(ConstraintConstants.h5)
            make.left.equalToSuperview().offset(ConstraintConstants.w13)
            make.bottom.equalToSuperview()
            make.right.equalToSuperview().offset(-ConstraintConstants.w13)
        }
    }

}

extension CalendarViewController: FSCalendarDataSource, FSCalendarDelegate {
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        selectedDateLabel.text = self.dateFormatter.string(from: date)
        print("did select date \(self.dateFormatter.string(from: date))")
        let selectedDates = calendar.selectedDates.map({self.dateFormatter.string(from: $0)})
        print("selected dates is \(selectedDates)")
        if monthPosition == .next || monthPosition == .previous {
            calendar.setCurrentPage(date, animated: true)
        }
    }
}

extension CalendarViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return ConstraintConstants.h70
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sessions.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: SessionCell.name) as! SessionCell
        return cell
    }
    
}
