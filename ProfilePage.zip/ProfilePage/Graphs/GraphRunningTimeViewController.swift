//
//  GraphRunningTimeViewController.swift
//  Meditatio kz
//
//  Created by Abai Kalikov on 10/22/19.
//  Copyright © 2019 Nazhmeddin Babakhanov. All rights reserved.
//

import Foundation
import UIKit
import SnapKit

class GraphRunningTimeViewController: UIViewController {
    
    lazy var graphStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .horizontal
        stackView.alignment = .bottom
        stackView.distribution = .fillEqually
        stackView.spacing = 5
        return stackView
    }()

    lazy var indexStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .horizontal
        stackView.alignment = .bottom
        stackView.distribution = .fillEqually
        stackView.spacing = 5
        return stackView
    }()

    let graphColor: UIColor = UIColor(red: 127/255, green: 97/255, blue: 245/255, alpha: 1.0)

    var presenter: GraphRunningTimePresenter!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.presenter = GraphRunningTimePresenter(runningTimeRepository: RunningTimeRepository.instance)
        presenter.attachView(view: self)
        presenter.viewDidLoad()
        setupViews()
        setupLayout()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        presenter.viewWillAppear()
    }

    //MARK: Graph Support

    func removeGraphElements () {
        removeIndexElements()
        removeAllGraphElements()
    }

    func newGraphElement (timeGraphData: TimeGraphData) {
        addIndexElement(timeGraphData: timeGraphData)
        addGraphElement(timeGraphData: timeGraphData)
    }

    private func removeIndexElements () {
        for view in indexStackView.arrangedSubviews {
            view.removeFromSuperview()
        }
    }

    private func removeAllGraphElements () {
        for view in graphStackView.arrangedSubviews {
            view.removeFromSuperview()
        }
    }

    private func addIndexElement (timeGraphData: TimeGraphData) {
        let weekendLabelHeight: CGFloat = 8.0

        let weekendLabel = UILabel()
        weekendLabel.text = timeGraphData.month
        weekendLabel.font = UIFont.systemFont(ofSize: weekendLabelHeight)
        weekendLabel.textAlignment = .center
        weekendLabel.textColor = #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)
        weekendLabel.heightAnchor.constraint(equalToConstant: weekendLabelHeight).isActive = true

        indexStackView.addArrangedSubview(weekendLabel)
        indexStackView.translatesAutoresizingMaskIntoConstraints = false;
    }

    private func addGraphElement (timeGraphData: TimeGraphData) {

        let amountLabelFontSize: CGFloat = 9.0
        let amountLabelPadding: CGFloat = 15.0
        let height = heightPixelsDependOfPercentage(percentage: timeGraphData.percentage)
        let totalHeight = height + amountLabelPadding

        let verticalStackView: UIStackView = UIStackView()
        verticalStackView.axis = .vertical
        verticalStackView.alignment = .fill
        verticalStackView.distribution = .fill
        verticalStackView.spacing = 8.0


        let amountLabel = UILabel()
        amountLabel.text = timeGraphData.amount
        amountLabel.font = UIFont.systemFont(ofSize: amountLabelFontSize)
        amountLabel.textAlignment = .center
        amountLabel.textColor = UIColor.darkText
        amountLabel.adjustsFontSizeToFitWidth = true
        amountLabel.heightAnchor.constraint(equalToConstant: amountLabelFontSize).isActive = true

        if height != 0 {
            let view = UIView()
            view.backgroundColor = graphColor
            view.layer.cornerRadius = 2
            view.clipsToBounds = true
            view.heightAnchor.constraint(equalToConstant: height).isActive = true
            verticalStackView.addArrangedSubview(amountLabel)
            verticalStackView.addArrangedSubview(view)
        } else {
            let view = UIView()
            view.backgroundColor = #colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1)
            view.layer.cornerRadius = 2
            view.clipsToBounds = true
            view.heightAnchor.constraint(equalToConstant: height).isActive = true
            verticalStackView.addArrangedSubview(view)
        }

        verticalStackView.heightAnchor.constraint(equalToConstant: totalHeight).isActive = true
        verticalStackView.translatesAutoresizingMaskIntoConstraints = false;

        graphStackView.addArrangedSubview(verticalStackView)
        graphStackView.translatesAutoresizingMaskIntoConstraints = false;
    }

    private func heightPixelsDependOfPercentage (percentage: Double) -> CGFloat {
        let maxHeight: CGFloat = 90.0
        return (CGFloat(percentage) * maxHeight) / 100
    }

    func setupViews() {
        view.layer.borderColor = UIColor.black.cgColor
        view.addSubViews(views: [graphStackView, indexStackView])
    }

    func setupLayout() {
        graphStackView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(-ConstraintConstants.h5)
            make.height.equalTo(ConstraintConstants.h75)
            make.width.equalTo(ConstraintConstants.w150)
            make.centerX.equalToSuperview()
        }

        indexStackView.snp.makeConstraints { (make) in
            make.top.equalTo(graphStackView.snp.bottom).offset(-ConstraintConstants.h5)
            make.height.equalTo(ConstraintConstants.h15)
            make.width.equalTo(ConstraintConstants.w150)
            make.centerX.equalToSuperview()
        }
    }
}

extension GraphRunningTimeViewController : GraphRunningTimeView {

    func updateInfo (runningTimeCollection: [TimeGraphData]){
        removeAllGraphElements()
        for timeGraphData in runningTimeCollection {
            newGraphElement(timeGraphData: timeGraphData)
        }
    }
}
